package MapeCalses;

public class P2 {

}
